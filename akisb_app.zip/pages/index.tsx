import React from 'react';

const Home = () => {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Akış Bilinci Uygulaması</h1>
      <p>Hoş geldiniz. Bu, temel Next.js tabanlı bir arayüzdür.</p>
    </div>
  );
};

export default Home;
