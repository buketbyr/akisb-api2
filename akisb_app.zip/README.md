# Akış Bilinci Uygulaması

Next.js tabanlı temel başlangıç arayüzü.